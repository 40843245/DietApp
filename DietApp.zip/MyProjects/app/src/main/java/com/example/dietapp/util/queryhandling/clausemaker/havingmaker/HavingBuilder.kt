package com.example.dietapp.util.queryhandling.clausemaker.havingmaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionmaker.ConditionBuilder

class HavingBuilder() : ConditionBuilder() {
}