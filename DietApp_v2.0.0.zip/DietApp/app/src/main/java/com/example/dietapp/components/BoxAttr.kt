package com.example.dietapp.components

import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.ui.Modifier

data class BoxAttr(
    val modifier:Modifier = Modifier.wrapContentSize()
)