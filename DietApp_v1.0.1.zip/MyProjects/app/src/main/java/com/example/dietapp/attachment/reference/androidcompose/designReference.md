# Diet App
## reference of ui components design pattern in Android Compose
See [material 3 design](https://m3.material.io/)