package com.example.dietapp.util.queryhandling.querymaker.operation.basicoperation.table.describetablequery

import com.example.dietapp.util.queryhandling.querymaker.base.BaseQuery

class DescribeTableQueryBuilder():BaseQuery() {
    override fun table(table: String): DescribeTableQueryBuilder {
        super.table(table)
        return this
    }

    override fun build():String{
        val stringBuilder = StringBuilder()
        stringBuilder.append("DESCRIBE ")
        stringBuilder.append(this.tables[0])
        stringBuilder.append(" ;")
        return stringBuilder.toString()
    }
}