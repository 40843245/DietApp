package com.example.dietapp.test.unittest

import android.util.Log
import com.example.dietapp.util.datetime.DateUtil

object UnitTest {
    private final val TAG = "ExampleUnitTest"
    fun isValidDateExample1(){
        val date = "01/01/2001"
        assert(DateUtil.isValidDate(date))
        Log.d(TAG,"isValidDateExample1")
    }

    fun isValidDateExample2(){
        val date = "10/01/2001"
        assert(DateUtil.isValidDate(date))
        Log.d(TAG,"isValidDateExample2")
    }
}