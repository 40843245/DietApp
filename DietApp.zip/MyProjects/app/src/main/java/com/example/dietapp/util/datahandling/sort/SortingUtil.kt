package com.example.dietapp.util.datahandling.sort

object SortingUtil {
    fun sort(){
    }
}