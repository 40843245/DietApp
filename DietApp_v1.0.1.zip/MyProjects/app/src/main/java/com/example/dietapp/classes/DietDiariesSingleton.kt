package com.example.dietapp.classes

object DietDiariesSingleton{
    var dietDiaries:MutableList<DietDiary> = mutableListOf()
}