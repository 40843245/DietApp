package com.example.dietapp.util.queryhandling.clausemaker.wheresmaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionsmaker.ConditionsBuilder

class WheresBuilder(): ConditionsBuilder() {
}