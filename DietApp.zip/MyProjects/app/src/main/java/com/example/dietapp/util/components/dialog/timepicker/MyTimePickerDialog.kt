package com.example.dietapp.util.components.dialog.timepicker

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar

class MyTimePickerDialog(private val _buttonText :String) {
    var buttonText : String = _buttonText

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun popUp(){
        var showTimePicker by remember { mutableStateOf(false) }
        Box(
            modifier = Modifier.height(40.dp).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Button(
                modifier = Modifier.fillMaxSize(),
                onClick = { showTimePicker = true }
            ) {
                Text(text = buttonText)
            }
        }

        if (showTimePicker) {
            var selectedTime: TimePickerState? by remember { mutableStateOf(null) }
            MyTimePickerDialogUtil.DialUseStateExample(
                onDismiss = {},
                onConfirm = { time ->
                    selectedTime = time
                },
            )

            if (selectedTime != null) {
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, selectedTime!!.hour)
                cal.set(Calendar.MINUTE, selectedTime!!.minute)
                cal.isLenient = false

                val formatter = SimpleDateFormat("hh:MM:ss")
                buttonText = formatter.format(cal.time)
            }
        }
    }
}