package com.example.dietapp.enumclass

enum class ProgressIndicatorEnum {
    Linear,
    Circular,
}