package com.example.dietapp.classes

data class DietDiary(
    val id: Int,
    var name:String,
    val mealDate: String,
    val mealTime: String,
)