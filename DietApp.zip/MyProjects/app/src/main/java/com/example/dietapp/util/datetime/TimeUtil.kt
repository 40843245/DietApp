package com.example.dietapp.util.datetime

import java.text.SimpleDateFormat
import java.util.Locale

object TimeUtil {
    fun isValidTime(dateStr:String):Boolean{
        try {
            val formatter = SimpleDateFormat("hh:MM:ss", Locale.getDefault())
            val time = formatter.parse(dateStr)
            return true
        }catch (ex:Exception){
            return false
        }
    }
}