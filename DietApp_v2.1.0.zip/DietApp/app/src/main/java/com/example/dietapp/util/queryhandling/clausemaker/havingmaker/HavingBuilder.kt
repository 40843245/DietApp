package com.example.dietapp.util.queryhandling.clausemaker.havingmaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionmaker.ConditionBuilder

/**
 * HavingBuilder
 *
 * @constructor A builder that create a part of `HAVING` clause about MySQL.
 */
class HavingBuilder() : ConditionBuilder() {
}