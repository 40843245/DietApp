package com.example.dietapp.util.dateformatter

object DateFormatterPattern {
    val pattern = "dd-MM-yyyy"
}