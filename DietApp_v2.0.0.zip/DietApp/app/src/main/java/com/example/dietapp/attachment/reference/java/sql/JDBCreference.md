# Diet App
## JDBC
### Java Official website
See [JDBC Introduction](https://docs.oracle.com/javase/tutorial/jdbc/overview/index.html#:~:text=This%20JDBC%20Java%20tutorial%20describes%20how%20to%20use%20JDBC%20API)

### Kotlin Official website
See [Connect and retrieve data from databases in Kotlin (Kotlin Official docs)](https://kotlinlang.org/docs/data-analysis-connect-to-db.html#connect-to-database)