package com.example.dietapp.classes

data class Nutrition(
    val sodium:UInt,
    val glucose:UInt,
    val sugar:UInt,
    val potassium: UInt,
    val protein: UInt,
    )