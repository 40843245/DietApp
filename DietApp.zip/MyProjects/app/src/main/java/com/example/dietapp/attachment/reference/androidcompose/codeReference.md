# Diet App
## code reference
About how to dynamic build a sql statement, see [Creating a Dynamic Query Builder in Java: A Step-by-Step Guide](https://medium.com/@matblockgreninja/creating-a-dynamic-query-builder-in-java-a-step-by-step-guide-d3a0253e6986#:~:text=In%20this%20guide,%20we%20will%20be%20creating%20a%20QueryBuilder%20class), I copy it into the following file -- com.example.dietapp.util.queryhandling.querymaker.operation.basicoperation.table.selectquery.SelectQueryBuilder]
