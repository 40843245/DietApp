package com.example.dietapp.classes

data class Food(
    val name:String,
    //val nutrition: Nutrition,
    //val grams: UInt,
)