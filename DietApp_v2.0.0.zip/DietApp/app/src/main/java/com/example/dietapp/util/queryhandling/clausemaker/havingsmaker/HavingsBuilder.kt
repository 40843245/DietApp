package com.example.dietapp.util.queryhandling.clausemaker.havingsmaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionsmaker.ConditionsBuilder

/**
 * HavingsBuilder
 *
 * @constructor A builder that create a `HAVING` clause about MySQL.
 */

class HavingsBuilder(): ConditionsBuilder() {
}