package com.example.dietapp.util.queryhandling.querymaker.operation.basicoperation.database.showdatabasesquery

import com.example.dietapp.util.queryhandling.querymaker.base.BaseQuery

class ShowDatabasesQueryBuilder(): BaseQuery() {

    override fun build():String{
        val stringBuilder = StringBuilder()
        stringBuilder.append("SHOW DATABASES ")
        stringBuilder.append(" ;")
        return stringBuilder.toString()
    }
}