package com.example.dietapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.dietapp.extension.string.StringExtensionTest
import com.example.dietapp.resources.stringresources.StringResourcesSingleton
import com.example.dietapp.ui.theme.DietAppTheme
import com.example.dietapp.util.queryhandling.clausemaker.escapemaker.EscapeBuilderTest
import com.example.dietapp.util.queryhandling.clausemaker.fieldmaker.FieldBuilderTest
import com.example.dietapp.util.queryhandling.clausemaker.fieldsmaker.FieldsBuilderTest
import com.example.dietapp.util.queryhandling.clausemaker.patternmaker.PatternBuilderTest
import com.example.dietapp.util.queryhandling.querymaker.operation.basicoperation.table.createtablequery.CreateTableQueryBuilderTest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DietAppTheme {
                StringResourcesSingleton.initResource()
                CreateTableQueryBuilderTest.test1()
            }
        }
    }
}