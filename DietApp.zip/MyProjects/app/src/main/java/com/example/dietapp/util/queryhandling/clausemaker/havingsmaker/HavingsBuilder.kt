package com.example.dietapp.util.queryhandling.clausemaker.havingsmaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionsmaker.ConditionsBuilder

class HavingsBuilder(): ConditionsBuilder() {
}