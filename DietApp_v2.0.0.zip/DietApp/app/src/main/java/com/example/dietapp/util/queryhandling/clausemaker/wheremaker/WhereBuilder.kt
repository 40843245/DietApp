package com.example.dietapp.util.queryhandling.clausemaker.wheremaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionmaker.ConditionBuilder

/**
 * PatternBuilder
 *
 * @constructor A builder that create a `WHERE` clause about MySQL.
 */

class WhereBuilder(): ConditionBuilder() {
}