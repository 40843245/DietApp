package com.example.dietapp.util.queryhandling.clausemaker.wheremaker

import com.example.dietapp.util.queryhandling.clausemaker.conditionmaker.ConditionBuilder

class WhereBuilder(): ConditionBuilder() {
}