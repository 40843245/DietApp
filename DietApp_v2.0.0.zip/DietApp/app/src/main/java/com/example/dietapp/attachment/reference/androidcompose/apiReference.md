# Diet App
## API reference
### components in Android Compose
About current API reference of components in Android Compose, see [androidx.compose.material (Official docs)](https://developer.android.com/reference/kotlin/androidx/compose/material3/package-summary)
