package com.example.dietapp.result.queryresult

object DietDiaryQueryResult {
    var queryResult = mutableListOf("")
}