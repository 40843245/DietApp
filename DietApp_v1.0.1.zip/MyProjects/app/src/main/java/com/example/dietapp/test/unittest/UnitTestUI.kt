package com.example.dietapp.test.unittest

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable

object UnitTestUI {
    @Composable
    fun show(){
        Column {

        }
    }
}